function varargout = roiSelection(varargin)
% ROISELECTION MATLAB code for roiSelection.fig
%      ROISELECTION, by itself, creates a new ROISELECTION or raises the existing
%      singleton*.
%
%      H = ROISELECTION returns the handle to a new ROISELECTION or the handle to
%      the existing singleton*.
%
%      ROISELECTION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ROISELECTION.M with the given input arguments.
%
%      ROISELECTION('Property','Value',...) creates a new ROISELECTION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before roiSelection_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to roiSelection_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help roiSelection

% Last Modified by GUIDE v2.5 02-Oct-2019 10:27:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @roiSelection_OpeningFcn, ...
                   'gui_OutputFcn',  @roiSelection_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

function h = initData(h)
h.originalImage = [];
h.adjustedImage = [];
h.imageFileName = [];
h.hImage = [];
h.adjustMaxLevel = 56536;
h.imGamma = 1.0;

h.roiMaxSize = 50;
h.thresh = 0.001;

h.rois = cell(1,0);

h.imMinThreshSliderListener = addlistener(h.imMinThreshSlider, 'Value', 'PostSet', @(src, event)imMinThreshSlider_DragCallback(src, event, guidata(h.imMinThreshSlider)));
h.imMaxThreshSliderListener = addlistener(h.imMaxThreshSlider, 'Value', 'PostSet', @(src, event)imMaxThreshSlider_DragCallback(src, event, guidata(h.imMaxThreshSlider)));
h.imGammaSliderListener = addlistener(h.imGammaSlider, 'Value', 'PostSet', @(src, event)imGammaSlider_DragCallback(src, event, guidata(h.imGammaSlider)));



% --- Executes just before roiSelection is made visible.
function roiSelection_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to roiSelection (see VARARGIN)

% Choose default command line output for roiSelection
handles.output = hObject;

handles = initData(handles);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes roiSelection wait for user response (see UIRESUME)
% uiwait(handles.roiSelectionFigure);


% --- Outputs from this function are returned to the command line.
function varargout = roiSelection_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in loadImageButton.
function loadImageButton_Callback(hObject, eventdata, handles)
% hObject    handle to loadImageButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[f,p] = uigetfile({'*.tif', '*.jpg'},'Select the database mat-file');
handles.originalImage = [];
handles.grayImage = [];
handles.adjustedImage = [];
handles.hImage = [];
if isequal(f,0)
   disp('User selected Cancel');
else
   f = fullfile(p, f);
   handles.imageFileName = f;
   handles.originalImage = imread(f);
   if size(handles.originalImage,3) == 3
       handles.grayImage = rgb2gray(handles.originalImage);
       handles.adjustedImage = handles.grayImage;
   else
       handles.grayImage = handles.originalImage;
        handles.adjustedImage = handles.originalImage;
   end
   
   
   handles.imMin = min(min(handles.grayImage));
   handles.imMax = max(max(handles.grayImage));
   handles.imGamma = 1.0;
   
   imClass = class(handles.grayImage);
   if strcmp(imClass, 'uint16')
       handles.adjustMaxLevel = 65535;
   elseif strcmp(imClass, 'uint8')
       handles.adjustMaxLevel = 255;
   else
       handles.adjustMaxLevel = 1.0;
   end
   
   
   
   set(handles.imMinEdit, 'String', num2str(handles.imMin));
   set(handles.imMaxEdit, 'String', num2str(handles.imMax));
   set(handles.imGammaEdit, 'String', num2str(handles.imGamma));
   set(handles.imMinThreshSlider, 'Min', handles.imMin, 'Max', handles.imMax, 'Value', handles.imMin, 'SliderStep' , [0.001 0.01]);
   set(handles.imMaxThreshSlider, 'Min', handles.imMin, 'Max', handles.imMax, 'Value', handles.imMax, 'SliderStep' , [0.001 0.01]);
   set(handles.imGammaSlider, 'Min', 0.1, 'Max', 5, 'Value', handles.imGamma, 'SliderStep' , [0.01 0.1]);
   
   handles = showImage(handles);
end

guidata(hObject, handles);

function h = showImage(h)

h.adjustedImage = imadjust(h.grayImage, double([h.imMin h.imMax]) / h.adjustMaxLevel, [], h.imGamma);

if isempty(h.hImage)
    h.hImage = imshow(h.adjustedImage, 'Parent', h.displayAxe);
else
    set(h.hImage, 'CData', h.adjustedImage);
end


% --- Executes on slider movement.
function imMinThreshSlider_Callback(hObject, eventdata, handles)
% hObject    handle to imMinThreshSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

function imMinThreshSlider_DragCallback(src, eventdata, handles)
hObject = handles.imMinThreshSlider;

handles.imMin = get(hObject, 'Value');

handles = showImage(handles);

if handles.adjustMaxLevel == 1.0
    set(handles.imMinEdit, 'String', sprintf('%.3f', handles.imMin));
else
    set(handles.imMinEdit, 'String', sprintf('%.0f', handles.imMin));
end

guidata(hObject, handles);

function imMaxThreshSlider_DragCallback(src, eventdata, handles)

hObject = handles.imMaxThreshSlider;

handles.imMax = get(hObject, 'Value');

handles = showImage(handles);

if handles.adjustMaxLevel == 1.0
    set(handles.imMaxEdit, 'String', sprintf('%.3f', handles.imMax));
else
    set(handles.imMaxEdit, 'String', sprintf('%.0f', handles.imMax));
end

guidata(hObject, handles);

function imGammaSlider_DragCallback(src, eventdata, handles)

hObject = handles.imGammaSlider;

handles.imGamma = get(hObject, 'Value');

handles = showImage(handles);

set(handles.imGammaEdit, 'String', sprintf('%.2f', handles.imGamma));

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function imMinThreshSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to imMinThreshSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function imMaxThreshSlider_Callback(hObject, eventdata, handles)
% hObject    handle to imMaxThreshSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function imMaxThreshSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to imMaxThreshSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function imMinEdit_Callback(hObject, eventdata, handles)
% hObject    handle to imMinEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of imMinEdit as text
%        str2double(get(hObject,'String')) returns contents of imMinEdit as a double


% --- Executes during object creation, after setting all properties.
function imMinEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to imMinEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function imMaxEdit_Callback(hObject, eventdata, handles)
% hObject    handle to imMaxEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of imMaxEdit as text
%        str2double(get(hObject,'String')) returns contents of imMaxEdit as a double


% --- Executes during object creation, after setting all properties.
function imMaxEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to imMaxEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function imGammaSlider_Callback(hObject, eventdata, handles)
% hObject    handle to imGammaSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function imGammaSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to imGammaSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function imGammaEdit_Callback(hObject, eventdata, handles)
% hObject    handle to imGammaEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of imGammaEdit as text
%        str2double(get(hObject,'String')) returns contents of imGammaEdit as a double


% --- Executes during object creation, after setting all properties.
function imGammaEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to imGammaEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function [hdl, B, bw] = expandRoiFromPoint(hdl,  pt, rsz)

% if ~isfield(hdl, 'gaborFilters')
%     hdl.gaborFilters = gaborFilterBank(4,4,5,5);
% end

im = get(hdl.hImage,'CData');
[ydim, xdim] = size(im);

rsz = floor(rsz / 2);

cropIm = double(im(pt(1,2) - rsz(2): pt(1,2) + rsz(2), pt(1,1)-rsz(1):pt(1,1) + rsz(1)));
mn = min(min(cropIm));
mx = max(max(cropIm));
range = mx - mn;

%filter cropIm with gabor filters (4 of them)

% h = fspecial('prewitt');
% cropIm = imfilter(cropIm, h);
% cropIm = imfilter(cropIm, h');

%compute center mean of 3x3 to see if we are in low level or high level
%center situation

centerVal = mean2(im(pt(1,2) - 1: pt(1,2) + 1, pt(1,1)-1:pt(1,1) + 1));

mask = false(size(cropIm)); 
mask(rsz(2), rsz(1)) = true;
%W = graydiffweight(cropIm, mask, 'GrayDifferenceCutoff', centerVal);
W = graydiffweight(cropIm, centerVal, 'GrayDifferenceCutoff', centerVal);
[bw, d] = imsegfmm(W, mask, hdl.thresh);

se = strel('disk',3,4);
bw = imdilate(bw, se);

%fillIm = double(bw) * mx;
% if is empy inside we run a second time the algorithm
% cropIm(bw == 1) = mx;
% centerVal = mean2(cropIm(rsz(2) - 1: rsz(2) + 1, rsz(1)-1:rsz(1) + 1));
% 
% mask = false(size(cropIm)); 
% mask(rsz(2), rsz(1)) = true;
% W = graydiffweight(cropIm, mask, 'GrayDifferenceCutoff', centerVal);
% thresh = 0.01;
% [bw, d] = imsegfmm(W, mask, thresh);

[B,L] = bwboundaries(bw,'noholes');

coord = B{1};
mn = min(coord, [], 1);
mx = max(coord, [], 1);
bw = bw(mn(1):mx(1), mn(2):mx(2));


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function roiSelectionFigure_WindowButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to roiSelectionFigure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

point1 = get(gca,'CurrentPoint');    % button down detected
if point1(1,1) < 1 || point1(1, 2) < 1
    return;
end
[sy, sx] = size(handles.adjustedImage);
if point1(2,1) >sx || point1(2, 2) > sy
    return;
end

rsz = [handles.roiMaxSize handles.roiMaxSize];
halfRsz = fix(rsz / 2);
[handles, B, bw] = expandRoiFromPoint(handles,  point1, rsz);

x = B{1}(:,2)' + (point1(1,1) - halfRsz(1));
y = B{1}(:,1)' + (point1(1,2) - halfRsz(2));

hold on;
hline = line(x,y);
hold off;

handles = addRoi(handles, x, y, bw, point1, handles.roiMaxSize, hline);

guidata(hObject, handles);


function h = addRoi(h, x, y, bw, pt, maxSize, hline)

roi = struct('Coordinates', [x; y], 'Map', bw, 'SourcePoint', pt, 'RoiMaxSize', maxSize, 'hline', hline, 'Rectangular', 0);

if isempty(h.rois)
    h.rois = {roi};
else
    h.rois{length(h.rois) + 1} = roi;
end

roiLst = cell(length(h.rois), 1);
for i=1:length(h.rois)
    roiLst{i} = sprintf('%d', i);
end

set(h.roiList, 'String', roiLst, 'Min', 1, 'Max', length(h.rois));


function h = recomputeRoiFromParameters(h)

if isempty(h.rois)
    return;
end

for i=1:length(h.rois)
    roi = h.rois{i};
    if ishandle(roi.hline)
        delete(roi.hline);
    end
    rsz = [h.roiMaxSize h.roiMaxSize];
    halfRsz = fix(rsz / 2);
    [h, B, bw] = expandRoiFromPoint(h,  roi.SourcePoint, rsz);
    
    x = B{1}(:,2)' + (roi.SourcePoint(1,1) - halfRsz(1));
    y = B{1}(:,1)' + (roi.SourcePoint(1,2) - halfRsz(2));
    
    hold on;
    roi.hline = line(x,y);
    hold off;
    
    roi.Coordinates = [x; y];
    roi.Map = bw;
    roi.RoiMaxSize = h.roiMaxSize;
    
    h.rois{i} = roi;
end



function segmentThresholdEdit_Callback(hObject, eventdata, handles)
% hObject    handle to segmentThresholdEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of segmentThresholdEdit as text
%        str2double(get(hObject,'String')) returns contents of segmentThresholdEdit as a double

v = str2double(get(hObject,'String'));
handles.thresh = v;
handles = recomputeRoiFromParameters(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function segmentThresholdEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to segmentThresholdEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function roiMaxSizeEdit_Callback(hObject, eventdata, handles)
% hObject    handle to roiMaxSizeEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of roiMaxSizeEdit as text
%        str2double(get(hObject,'String')) returns contents of roiMaxSizeEdit as a double

handles.roiMaxSize = str2double(get(hObject,'String'));

handles = recomputeRoiFromParameters(handles);

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function roiMaxSizeEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to roiMaxSizeEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in roiList.
function roiList_Callback(hObject, eventdata, handles)
% hObject    handle to roiList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns roiList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from roiList


% --- Executes during object creation, after setting all properties.
function roiList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to roiList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in deleteRoiButton.
function deleteRoiButton_Callback(hObject, eventdata, handles)
% hObject    handle to deleteRoiButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

v = get(handles.roiList, 'Value');

nSel = length(v);
for i=1:nSel
    if ishandle(handles.rois{v(i)}.hline)
        delete(handles.rois{v(i)}.hline);
    end
end

handles.rois(v) = [];
if length(handles.rois) > 0
    roiLst = cell(length(handles.rois), 1);
    for i=1:length(handles.rois)
        roiLst{i} = sprintf('%d', i);
    end
    
    set(handles.roiList, 'String', roiLst, 'Min', 1, 'Max', length(handles.rois), 'Value', 1);
end


guidata(hObject, handles);


% --- Executes on button press in exportRoisButton.
function exportRoisButton_Callback(hObject, eventdata, handles)
% hObject    handle to exportRoisButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


[filename, pathname] = uiputfile( ...%ask for the file where to export rois
    {'*.mat','Mat file'}, ...
    'Save as');
if isempty(pathname)| pathname==0,
    return;
end

ROIS = handles.rois;
try
    save(fullfile(pathname, filename),'ROIS');
catch
    errordlg('Could not save the rois to the mat file. Check the access rights!');
end
    